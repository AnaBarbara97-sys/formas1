import 'package:flutter/material.dart';

import '../widgets/const.dart';


class InputDecorations {

  static InputDecoration authInputDecorations({
    required String labelText,
    required String hinText,
    IconData? prefixIcon,
  }){
   return  InputDecoration(
              enabledBorder: const UnderlineInputBorder(
                borderSide: BorderSide(
                  color: kSecundaryColor,
                  ),
              ),
              focusedBorder: const UnderlineInputBorder(
                borderSide: BorderSide(
                  color: kSecundaryColor,
                  width: 2,
                )
              ),
              hintText: hinText,
              labelText: labelText,
              labelStyle: const TextStyle(
                color: Colors.grey,
              ),
              prefixIcon: prefixIcon != null ?
              Icon(prefixIcon, color: kSecundaryColor) : 
              const Icon(Icons.email_sharp, color: kSecundaryColor),
            );
  }

}