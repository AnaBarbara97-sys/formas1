// este archivo almacena las librerias de los modelos
export 'package:formas/models/product.dart';