// Este archivo contiene todos los colores que se usan en la APP
import 'package:flutter/material.dart';


//Colores principales de la app
const kPrimaryColor = Color(0xffFFB97D);
const kSecundaryColor = Color(0xffE28BC7);

// Colores para las cartas
const kBoxMainColor = Color(0xffFF90B3);
const kBoxSecundaryColor = Color(0xffe29578);
const kIconColor = Color(0xffF9F871);


// Color para la caja de resultado
const kBoxResultColor = Color(0xffFFB97D);

const kColorAl = Colors.white;

//Colores principales para los textos
const kPrimaryTextColor = Colors.white;

const kInactiveCardColor = Color(0xffFF90B3);
const kActiveCardColor = Color(0xffFFB97D);

const kIconInactiveColor = Color(0xff564147);
const kIconActiveColor = Color(0xffBDA5AC);

const kTextLabelStyle = TextStyle(
  fontSize: 50,
  color: Colors.white,
);

const kTextLabelStyleGeneral = TextStyle(
  fontSize: 30,
  color: Colors.white,
);

const kTextLabelStyleImcMifflin = TextStyle(
  fontSize: 30,
  color: Colors.white,
  fontWeight: FontWeight.bold,
);





