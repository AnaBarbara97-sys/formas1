import 'package:flutter/material.dart';

class ProductImage extends StatelessWidget {
  final String? rutaImg;
  const ProductImage({ Key? key, required this.rutaImg }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(right: 10, left: 10, top: 10),
      child: Container(
        width: double.infinity,
        height: 450,
        decoration: _buildBoxDecoration(),
        child:  ClipRRect(
          borderRadius: const BorderRadius.only(
          topLeft: Radius.circular(45), topRight: Radius.circular(45),
          ),
          child: rutaImg == null
            ? const Image(image: AssetImage('assets/no-image.jpeg'), fit: BoxFit.cover,)
            : FadeInImage(
            image: NetworkImage(rutaImg!),
            placeholder: const AssetImage('assets/jar-loading.gif'),
            fit: BoxFit.cover,
            ),
        ),
      ),
    );
  }

  BoxDecoration _buildBoxDecoration() =>  BoxDecoration(
    color: Colors.cyanAccent,
    borderRadius: const BorderRadius.only(
      topLeft: Radius.circular(45), topRight: Radius.circular(45),
    ),
    boxShadow: [
      BoxShadow(
        color: Colors.black.withOpacity(0.08),
        blurRadius: 10,
        offset: const Offset(0, 5)
      )
    ]
  );
}