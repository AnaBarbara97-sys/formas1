import 'package:flutter/material.dart';
import 'package:formas/screens/loading_product.dart';
import 'package:formas/services/products_service.dart';
import 'package:formas/widgets/widgets.dart';
import 'package:provider/provider.dart';


class HomePage extends StatelessWidget {
   String? email;
 
   HomePage({ Key? key,  this.email }) : super(key: key);

  @override
  Widget build(BuildContext context) {

    final servicioProductos = Provider.of<ProductsService>(context);

    if(servicioProductos.isLoading) return const LoadingProduct();

    return Scaffold(
      appBar: AppBar(
         title:  const Text('Productos'),
      ),
        body: ListView.builder(
          itemCount: servicioProductos.productos.length,
          itemBuilder: (BuildContext context, int index) => GestureDetector(
            onTap: () => {
              servicioProductos.productoSeleccionado = servicioProductos.productos[index].copia(),
              Navigator.pushNamed(context, 'product')
            },
            child:  ProductCard(
              product: servicioProductos.productos[index]
            )),
        ),
        floatingActionButton: FloatingActionButton(
          child: const Icon(Icons.add),
          onPressed: (){}),
    );
  }
}