
import 'package:flutter/material.dart';
import 'package:formas/services/services.dart';
import 'package:formas/widgets/widgets.dart';
import 'package:provider/provider.dart';
import '../ui/input_decorations.dart';

class ProductScreens extends StatelessWidget {
  const ProductScreens({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context) {

    final servicioProducto = Provider.of<ProductsService>(context);

    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          children: [
            Stack(
              children:  [
                 ProductImage(
                    rutaImg: servicioProducto.productoSeleccionado.imagen,
                 ),
                  Positioned(
                  top: 60,
                  left: 20,
                  child: IconButton(
                  onPressed: () => Navigator.of(context).pop(), 
                  icon: const Icon(Icons.arrow_back_ios_new_outlined,
                  color: Colors.white,
                    ),
                  ),
                  ),
                   Positioned(
                    top: 60,
                    right: 20,
                    child: IconButton(
                      onPressed: (){},
                     icon: const Icon(Icons.camera_alt_outlined,
                    size: 40,
                    color: Colors.white,
                      ),
                    ),
                   ),
              ],
            ),

            const SizedBox(height: 40,),

            const _FormularioProductos()
          ],
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.endDocked,
      floatingActionButton: FloatingActionButton(
        child: const Icon(Icons.save_outlined),
        onPressed: (){
          //TODO: Guardar productos
        }),
    );
  }
}

class _FormularioProductos extends StatelessWidget {
  const _FormularioProductos({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
     final servicioProducto = Provider.of<ProductsService>(context);
    return Container(
      width: double.infinity,
      decoration: _buildFormDecoration(),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: Form(
          child: Column(
            children: [
              const SizedBox( height: 10,),
             TextFormField(
            initialValue: servicioProducto.productoSeleccionado.nombre,
            autocorrect: false,
            keyboardType: TextInputType.emailAddress,
            decoration: InputDecorations.authInputDecorations(
              labelText: 'Producto', 
              hinText: servicioProducto.productoSeleccionado.nombre,
              prefixIcon: Icons.shop_outlined),
          ),
              const SizedBox(height: 10,),
               TextFormField(
            initialValue: '\$' + servicioProducto.productoSeleccionado.precio.toString(),
            autocorrect: false,
            keyboardType: TextInputType.emailAddress,
            decoration: InputDecorations.authInputDecorations(
              labelText: 'Precio', 
              hinText: '\$' + servicioProducto.productoSeleccionado.precio.toString(),
              prefixIcon: Icons.money),
          ),
          const  SizedBox(height: 30,),
          SwitchListTile(
            title:  Text(servicioProducto.productoSeleccionado.disponibilidad == true ? 'Disponible' 
            : 'No disponible'),
            value: servicioProducto.productoSeleccionado.disponibilidad == true ? true : false, 
            activeColor: Colors.blueGrey,
            onChanged: (value){

            }),
            ],
          )),
      ),
    );
  }

  BoxDecoration _buildFormDecoration() => const BoxDecoration(
    color: Colors.white,
    borderRadius: BorderRadius.only(
      bottomLeft: Radius.circular(25),
      bottomRight: Radius.circular(25),
    )
  );
}